import pandas as pd
from sklearn.model_selection import train_test_split
import seaborn as sns
import numpy as np
from sklearn.linear_model import LinearRegression
from category_encoders.leave_one_out import LeaveOneOutEncoder
from category_encoders.one_hot import OrdinalEncoder
from sklearn.pipeline import Pipeline
from sklearn.metrics import mean_squared_error
from sklearn.base import BaseEstimator, TransformerMixin
import yaml
import joblib 

class OutlierRemover(BaseEstimator,TransformerMixin):
    def __init__(self, cols, min_q = 0.01, max_q = 0.99):
        self.cols = cols
        self.min_q = min_q
        self.max_q = max_q
    
    def fit(self, X, y=None):
        self.thresholds_dict = {
            col: (np.quantile(X[col], self.min_q), np.quantile(X[col], self.max_q))
            for col in self.cols
        }

        return self
    
    def transform(self, X):
        return X.assign(**{
            col: X[col].clip(lower=self.thresholds_dict[col][0], upper=self.thresholds_dict[col][1])
            for col in self.cols
        })

def fit(dataset_path="Credit.csv", target_name='Rating', config="config.yaml"):
    dataset = pd.read_csv(dataset_path, sep=',').drop("Unnamed: 0", axis=1)
    train, test = train_test_split(dataset, test_size=0.2, random_state=42)
    train, val = train_test_split(train, test_size=0.2, random_state=42)

    with open(config, 'r') as f:
        config = yaml.safe_load(f)

    model_pipeline = Pipeline([
        ('loo_enc', LeaveOneOutEncoder(cols=config['encoders_cols']['loo_enc'])),
        ('ord_enc', OrdinalEncoder(cols=config['encoders_cols']['ord_enc'])),
        ('outliers', OutlierRemover(cols=config['encoders_cols']['outliers'])),
        ('lr', LinearRegression())
    ])

    model_pipeline.fit(X=train.drop(target_name, axis=1), y=train[target_name])
    
    with open("model_pipeline.joblib", 'wb') as f:
        joblib.dump(model_pipeline, f)

    train.to_parquet("train.parquet")
    test.to_parquet("test.parquet")
    val.to_parquet("val.parquet")
    

    
def predict(data_path='.', fold='test', model_path='model_pipeline.joblib', target_name='Rating', config="config.yaml"):
    dataset = pd.read_parquet(f"{data_path}/{fold}.parquet")

    with open(model_path, 'rb') as f:
        model_pipeline = joblib.load(f)

    predictions = model_pipeline.predict(X=dataset.drop(target_name, axis=1))

    metric = mean_squared_error(
        y_pred=predictions,
        y_true=dataset[target_name],
        squared=False
    )

    with open(f"predictions_{fold}.yaml", "w") as f:
        yaml.dump({
            "metric": float(metric), 
            "predictions": list(map(int, predictions.tolist()))
        }, f)

    return metric